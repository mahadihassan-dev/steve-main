# Responsive YouTube Player as Coverflow Slider with Swiper.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/mark_sottek/pen/eYZdRaZ](https://codepen.io/mark_sottek/pen/eYZdRaZ).

Responsive Coverflow Slider for YouTube videos using Swiper-js and some JQuery.  Videos load and play when cover image is clicked and stop on slide change .  Boosting performance. Cover images are pulled from YouTube.  Swipeable - keyboard navigation.   Simple mark-up.  Simply replace the YouTube video ID in slides. Can extend the functionality using the Swiper-js API.   

Featuring New Orleans own Luke James.