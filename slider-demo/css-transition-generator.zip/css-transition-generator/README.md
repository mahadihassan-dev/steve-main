# CSS Transition Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/smpnjn/pen/zYPoGBZ](https://codepen.io/smpnjn/pen/zYPoGBZ).

