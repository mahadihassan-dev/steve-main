    // Some global vars
    let canvas = document.getElementById('bezier');
    let ctx = canvas.getContext('2d');
    let cubicBezierText = 'cubic-bezier(0.2, 0.8, 0.3, 0.7)';
    let transitionTime = 1;
    let delayTime = 0;
    let mouseDown = false;
    
    // Set canvas dimensions
    canvas.width = 510;
    canvas.height = 510;
    
    // Set start and end points
    let start = {x: 10, y: 490};
    let end = {x: 490, y: 10};

    // Set control points
    let controls = {
        controlPoint1: {x: 100, y: 100},
        controlPoint2: {x: 150, y: 150},

    }
    
    document.getElementById('bezier-curve').addEventListener('pointerdown', function(e) {
        try {
            let posX = e.clientX - this.getBoundingClientRect().left;
            let posY = e.clientY - this.getBoundingClientRect().top;

            if(!e.target.classList.contains('control')) {
                mouseDown = true;
                if(posX > 0 && posX < 200 && posY > 0 && posY < 200) {
                    if(posY > 0 && posY < 200 && posX > 0 && posX < 100) {
                        document.querySelector('.control.control-1').style.left = `${posX}px`;
                        document.querySelector('.control.control-1').style.top = `${posY}px`;
                        document.querySelector('.control.control-1').classList.add('active');
                        controls.controlPoint1 = { x: (posX / 200) * 500, y: (posY / 200) * 500 };
                    }
                    else {
                        document.querySelector('.control.control-2').style.left = `${posX}px`;
                        document.querySelector('.control.control-2').style.top = `${posY}px`;
                        document.querySelector('.control.control-2').classList.add('active');
                        controls.controlPoint2 = { x: (posX / 200) * 500, y: (posY / 200) * 500 };
                    }
                }
                drawCanvas();
                cubicBezierText = `cubic-bezier(${Math.round((controls.controlPoint1.x / 500) * 100) / 100}, ${1 - Math.round((controls.controlPoint1.y / 500) * 100) / 100}, ${Math.round((controls.controlPoint2.x / 500) * 100) / 100}, ${1 - (Math.round((controls.controlPoint2.y / 500) * 100) / 100)})`;
            }
        } catch(e) {
            console.log('Warning: out of bounds on Bezier Curve');
        }
    });
    
    // Generate a transition
    const generateTransition = function(cubic, time, delay) {
        return `all ${time}s ${cubic} ${delay}s`;
    }

    document.getElementById('css-code-for-transition').textContent = `transition: ${generateTransition(cubicBezierText, transitionTime, delayTime)};`;

    // Generate the cubic bezier curve
    const drawCanvas = function() {
        ctx.clearRect(0, 0, 500, 500);
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineCap = 'round';
        ctx.bezierCurveTo(
            controls.controlPoint1.x, controls.controlPoint1.y,
            controls.controlPoint2.x, controls.controlPoint2.y,
            end.x, end.y
        ); 
        ctx.strokeStyle = "white";
        ctx.lineWidth = 10;
        ctx.stroke();
        ctx.closePath();
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(controls.controlPoint1.x - 8, controls.controlPoint1.y - 8);
        ctx.strokeStyle = '#0275ff';
        ctx.lineWidth = 10;
        ctx.stroke();
        ctx.closePath();
        ctx.beginPath();
        ctx.moveTo(end.x, end.y);
        ctx.lineTo(controls.controlPoint2.x - 8, controls.controlPoint2.y - 8);
        ctx.strokeStyle = '#0275ff';
        ctx.lineWidth = 10;
        ctx.stroke();
    }

    // Draw points in right place
    document.querySelector('.control-1').style.left = `${controls.controlPoint1.x / 2.5}px`;
    document.querySelector('.control-1').style.top = `${controls.controlPoint1.y / 2.5}px`;
    document.querySelector('.control-2').style.left = `${controls.controlPoint2.x / 2.5}px`;
    document.querySelector('.control-2').style.top = `${controls.controlPoint2.y / 2.5}px`;

    document.getElementById('play-animation').addEventListener('click', function() {
        document.getElementById('animated-object').style.transition = 'none';
        document.getElementById('animated-object').classList.remove('moving');
        setTimeout(function() {
            document.getElementById('animated-object').style.transition = generateTransition(cubicBezierText, transitionTime, delayTime);
            document.getElementById('animated-object').classList.add('moving');
        }, 100)
    });

    // For when a user clicks on a control
    document.querySelectorAll('.control').forEach(function(item) {
        item.addEventListener('pointerdown', function(e) {
            mouseDown = true;
            this.classList.add('active');
        });
    });

    document.querySelector('#delay-container input').addEventListener('input', function(e) {
        document.querySelector('#delay-container h3 strong').textContent = this.value;
        delayTime = parseFloat(this.value);
        document.getElementById('css-code-for-transition').textContent = `transition: ${generateTransition(cubicBezierText, transitionTime, delayTime)};`;
    })

    document.querySelector('#duration-container input').addEventListener('input', function(e) {
        document.querySelector('#duration-container h3 strong').textContent = this.value;
        transitionTime = parseFloat(this.value);
        document.getElementById('css-code-for-transition').textContent = `transition: ${generateTransition(cubicBezierText, transitionTime, delayTime)};`;
    })

    // For selecting options
    document.querySelectorAll('.option').forEach(function(item) {
        item.addEventListener('click', function(e) {
            let ox1 = parseFloat(item.getAttribute('data-x-o1'));
            let oy1 = parseFloat(item.getAttribute('data-y-o1'));
            let ox2 = parseFloat(item.getAttribute('data-x-o2'));
            let oy2 = parseFloat(item.getAttribute('data-y-o2'));

            controls.controlPoint1 = { x: ox1 * 500, y: oy1 * 500 };
            controls.controlPoint2 = { x: ox2 * 500, y: oy2 * 500 };

            
            document.querySelector('.control.control-1').style.left = `${(ox1 * 200)}px`;
            document.querySelector('.control.control-1').style.top = `${(oy1 * 200)}px`;
            document.querySelector('.control.control-2').style.left = `${(ox2 * 200)}px`;
            document.querySelector('.control.control-2').style.top = `${(oy2 * 200)}px`;

            if(controls.controlPoint1.y === 0) {
                controls.controlPoint1.y = 16;
                document.querySelector('.control.control-1').style.top = `8px`;
            }
            if(controls.controlPoint2.y === 0) {
                controls.controlPoint2.y = 16;
                document.querySelector('.control.control-2').style.top = `8px`;
            }
        
            // Redraw canvas
            drawCanvas();

            // Update code
            cubicBezierText = `cubic-bezier(${Math.round((controls.controlPoint1.x / 500) * 100) / 100}, ${1 - Math.round((controls.controlPoint1.y / 500) * 100) / 100}, ${Math.round((controls.controlPoint2.x / 500) * 100) / 100}, ${1 - (Math.round((controls.controlPoint2.y / 500) * 100) / 100)})`;
            document.getElementById('css-code-for-transition').textContent = `transition: ${generateTransition(cubicBezierText, transitionTime, delayTime)};`;

        });
    })

    // Moving controls
    document.body.addEventListener('pointermove', function(e) {
        if(mouseDown === true) {
            let calcX = (e.clientX - document.getElementById('bezier-curve').getBoundingClientRect().left - 16);
            let calcY = (e.clientY - document.getElementById('bezier-curve').getBoundingClientRect().top - 16);
            
            if(calcX < 200 && calcX > 0 && calcY > 0 && calcY < 200) {
                let dataPoint = document.querySelector('.control.active').getAttribute('data-type');
                // Update data points
                controls[`${dataPoint}`].x = calcX * 2.5;
                controls[`${dataPoint}`].y = calcY * 2.5;
                
                cubicBezierText = `cubic-bezier(${Math.round((controls.controlPoint1.x / 500) * 100) / 100}, ${1 - Math.round((controls.controlPoint1.y / 500) * 100) / 100}, ${Math.round((controls.controlPoint2.x / 500) * 100) / 100}, ${1 - (Math.round((controls.controlPoint2.y / 500) * 100) / 100)})`;
                // Redraw canvas
                drawCanvas();

                // Update code
                document.getElementById('css-code-for-transition').textContent = `transition: ${generateTransition(cubicBezierText, transitionTime, delayTime)};`;

                document.querySelector('.control.active').style.left = `${calcX}px`;
                document.querySelector('.control.active').style.top = `${calcY}px`;

            }
        }
    });

    // When user releases control
    document.body.addEventListener('pointerup', function(e) {
        document.querySelectorAll('.control').forEach(function(item) {
            mouseDown = false;
            item.classList.remove('active');
        });
    });

    // Draw canvas on init
    drawCanvas();

