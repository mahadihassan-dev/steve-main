# CoverFlow with item flipping

A Pen created on CodePen.io. Original URL: [https://codepen.io/pete-rai/pen/jOzgeXQ](https://codepen.io/pete-rai/pen/jOzgeXQ).

An iPod style CoverFlow where cards are flipped when selected to reveal extended details on the reverse of the item.