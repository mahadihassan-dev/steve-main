# SwiperJS: Effect - Coverflow

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexpetergill/pen/ZEMOpXm](https://codepen.io/alexpetergill/pen/ZEMOpXm).

