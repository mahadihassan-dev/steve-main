# Coverflow Example (SCSS + light vanilla JS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jhnsnc/pen/YyRVNG](https://codepen.io/jhnsnc/pen/YyRVNG).

This is a simple example of how you might build a simple "coverflow" interactive with mostly Sass. JavaScript is only really used to change the coverflow state and handle events. All the positioning/styling is handled with Sass.

(UPDATE: images should now display more reliably.)