# Slick.js Gallery with cover flow effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/fionchadd/pen/oNpexPp](https://codepen.io/fionchadd/pen/oNpexPp).

