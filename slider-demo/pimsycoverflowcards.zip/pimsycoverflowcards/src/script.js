jQuery(document).ready(function($) {
    $('.cards__item').on('mouseover', function() {
        $('.active').removeClass('active');
        $(this).addClass("active").parents(".cards").addClass("active");
    });

    $('.cards__item').on('mouseout', function() {
        $('.active').removeClass('active');
        $('.cards').removeClass('active');
    });

	cardPosition();
    $(window).resize(function(event) {
    	cardPosition();
    });

});

function cardPosition() {
    var margins = 0;

    if (($('.cards__item').width() * $('.cards__item').length) > $('.cards').width()) {
    	cardCount = $('.cards__item').length;
    	cardWidth = $('.cards__item').width();
    	containerCard = $('.cards').width();
	    var margins = ((cardWidth * cardCount - containerCard) / cardCount + ((cardWidth * cardCount - containerCard) / cardCount / cardCount)) * -1;
    }

    $('.cards__item:not(:last-child)').css({
    	marginRight: margins+'px',
    })
}