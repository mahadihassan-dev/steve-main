# PimsyCoverFlowCards

A Pen created on CodePen.io. Original URL: [https://codepen.io/binsina/pen/LYrgmRW](https://codepen.io/binsina/pen/LYrgmRW).

