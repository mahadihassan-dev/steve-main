# Swiper JS with text animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Viorel/pen/rNrLRxX](https://codepen.io/Viorel/pen/rNrLRxX).

Simple Example Swiper JS with text animation