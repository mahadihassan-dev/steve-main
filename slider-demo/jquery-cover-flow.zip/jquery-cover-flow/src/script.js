var initSong = 7;
var songs = [
  {artist: "Lil Data", song: "Burnnn", album: "Folder Dot Zip"},
  {artist: "BROCKHAMPTON", song: "1997 DIANA", album: "1997 DIANA"},
  {artist: "KRANE, Portrait", song: "Italics", album: "Italics"},
  {artist: "Left At London", song: "Revolution Lover", album: "Transgender Street Legend, Vol.1"},
  {artist: "Foals", song: "Exits", album: "Everything Not Saved Will Be Lost: Part 1"},
  {artist: "Austin Weber", song: "Using the Internet for French", album: "Using the Internet for French"},
  {artist: "Phillipi & Rodrigo", song: "Retrogrado", album: "Paciencia"},
  {artist: "Holograph, Shadient", song: "Adé", album: "Adé"},
  {artist: "gasoiid", song: "s0-n2u", album: "s0-n2u"},
  {artist: "Ted Striker", song: "Love Is Gonna Make Us Stronger (Theme from Retry)", album: "Retry Original Soundtrack"},
  {artist: "Travis Bickle", song: "Off My Rocker", album: "Bickle Binch Forever"},
  {artist: "Grynpyret", song: "I Forgive", album: "I Forgive"},
  {artist: "Virtual Self", song: "ANGEL VOICES", album: "ANGEL VOICES"}
];

var songTotal = $(".coverflow .image").length;

function changeSong(number){
  $(".image[song="+number+"], .image[song="+number+"] img").removeAttr("style");
  for(i = 1; i <= songTotal - number; i++){
    $(".image[song="+ (number + i) +"] img").css("transform", "perspective(500px) translate3d("+ 80 * i +"%, 0, -"+ 25 * i +"px) rotateY(-"+ (65 + (5 * (i-1))) +"deg)");
    $(".image[song="+ (number + i) +"]").css("z-index", "-"+i);
  }
  for(i = -1; i >= -(number)+1; i--){
    $(".image[song="+ (number + i) +"] img").css("transform", "perspective(500px) translate3d("+ 80 * i +"%, 0, "+ 25 * i +"px) rotateY("+ (65 + (5 * -(i+1))) +"deg)");
    $(".image[song="+ (number + i) +"]").css("z-index", i);
  }
  $(".info .title h1").text(songs[number - 1].song);
  $(".info .title p").text(songs[number - 1].artist + " - " + songs[number - 1].album);
  if(number < 1){
    currentSong = 1;
  }else if(number > songTotal){
    currentSong = songTotal;
  }else{
    currentSong = number;
  }
}

$(".info .controls .left").click(function(){
  if(currentSong === 1){
    changeSong(currentSong);
  }else{
    changeSong(currentSong - 1);
  }
})

$(".info .controls .right").click(function(){
  if(currentSong === songTotal){
    changeSong(songTotal);
  }else{
    changeSong(currentSong + 1);
  }
})

$(".image").click(function(){changeSong($(this).attr("song").value);})

changeSong(initSong);