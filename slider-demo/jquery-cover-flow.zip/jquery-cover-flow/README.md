# jQuery Cover Flow

A Pen created on CodePen.io. Original URL: [https://codepen.io/harmonydoes/pen/ZPYGJL](https://codepen.io/harmonydoes/pen/ZPYGJL).

A reproduction of the Cover Flow interface from iTunes using jQuery.