# Vertical Cover-flow (drag / wheel)

A Pen created on CodePen.io. Original URL: [https://codepen.io/creativeocean/pen/GRrXxPO](https://codepen.io/creativeocean/pen/GRrXxPO).

GSAP timelines are CRAZY useful. This demo shows how to create individual timelines, that are then added to a main timeline, which is controlled via drag/wheel. Using this approach, you could create all sorts of interactive sequences.