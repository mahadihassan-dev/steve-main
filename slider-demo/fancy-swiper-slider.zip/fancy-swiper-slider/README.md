# Fancy Swiper slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/waterproofwebwizard/pen/dyqvyWv](https://codepen.io/waterproofwebwizard/pen/dyqvyWv).

