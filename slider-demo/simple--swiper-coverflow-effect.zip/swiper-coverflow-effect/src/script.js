
	
	var swiper = new Swiper('.mySwiper', {
		pagination: {
			el: '.swiper-pagination',
			clickable: true,
		},
		effect: 'coverflow',
		loop: true,
		centeredSlides: true,
		slidesPerView: 'auto',
		coverflowEffect: {
			rotate: 0,
			stretch: 80,
			depth: 200,
			modifier: 1, // 2,3
			slideShadows : false,
		}
	});

