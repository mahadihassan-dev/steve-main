# Carousel with drag and wheel

A Pen created on CodePen.io. Original URL: [https://codepen.io/supah/pen/xxJMbbg](https://codepen.io/supah/pen/xxJMbbg).

Experience the elegance of simplicity with this fully custom-made carousel of images. No frameworks, no fuss – just pure and fast performance, powered by CSS variables. With intuitive drag and drop capabilities and seamless mouse wheel navigation, you'll be sure to appreciate the beauty of this unique carousel design. Please don't use for a personal project or for commercial use.