// JS => Responsive
// $(document).ready(function () {
    
//     var iWidth479       =   window.innerWidth<479;
    
//     if ( $(".dash-main-left") != iWidth479) {


        
//         $(".dash-main-right").addClass('mb-full-width-0');
//         $(".dash-main-left-inner").addClass('sideBar-left');
//         // $(".dash-main-left").addClass("mb-hide-left-inner-full");

//         $(".sidebar_show_btn").click(function () {
//             if($(".dash-main-left-inner").hasClass("sideBar-left")){
//                 $(".sideBar-left").style.left = "0px !important";
//             } else {
//                 $(".sideBar-left").style.left = "265px !important";
//             }
//         });
    
        
//     }

    

// });